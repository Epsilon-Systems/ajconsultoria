* Important info

This is a 3rd party module which has been modified via a fork

The fork is available at git@github.com:gthomas2/vue2-datatable.git

The branch is 143_sort_order_default_to_asc
